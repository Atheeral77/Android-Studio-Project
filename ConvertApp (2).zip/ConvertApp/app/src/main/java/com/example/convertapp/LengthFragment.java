package com.example.convertapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class LengthFragment extends Fragment {

    ArrayAdapter arrayAdapter;
    Spinner sprFrom, sprTo;
    String[] units = {"mm", "cm", "m", "km"};

    int conversion[][] = {
            {0, -1, -3, -6},
            {1, 0, -2, -5},
            {3, 2, 0, -3},
            {6, 5, 3, 0}};
    EditText txtFrom, txtTo;
    Button convertButton;

    public LengthFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_length, container, false);

        arrayAdapter = new ArrayAdapter(view.getContext(), R.layout.checked_spinner, units);
        arrayAdapter.setDropDownViewResource(R.layout.spinner_list);

        sprFrom = view.findViewById(R.id.sprFrom);
        sprFrom.setAdapter(arrayAdapter);

        sprTo = view.findViewById(R.id.sprTo);
        sprTo.setAdapter(arrayAdapter);

        txtFrom = view.findViewById(R.id.txtFrom);
        txtTo = view.findViewById(R.id.txtTo);

        convertButton = view.findViewById(R.id.btnConvert);
        convertButton.setOnClickListener(v -> {
            if(txtFrom.getText().toString().trim().isEmpty()){
                txtFrom.requestFocus();
                txtFrom.setError("Please enter  number");
                return;
            }
            double result = Double.parseDouble(txtFrom.getText().toString())
                    * Math.pow(10, conversion[sprFrom.getSelectedItemPosition()][sprTo.getSelectedItemPosition()]);
            txtTo.setText(String.format("%.6f", result));
        });

        return view;
    }
}